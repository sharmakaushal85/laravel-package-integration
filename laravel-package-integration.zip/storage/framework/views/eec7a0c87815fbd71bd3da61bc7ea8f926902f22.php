<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">
                        <?php echo e($pageTitle ?? ''); ?>


                        <div class="btn-toolbar float-md-right" role="toolbar">
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('formbuilder::forms.index')); ?>" class="btn btn-sm btn-primary float-md-right">
                                    <i class="fa fa-arrow-left"></i> Back To My Forms
                                </a>
                                <button class="btn btn-primary btn-sm clipboard" data-clipboard-text="<?php echo e(route('formbuilder::form.render', $form->identifier)); ?>" data-message="Link Copied" data-original="Copy Form Link" title="Copy form URL to clipboard">
                                    <i class="fa fa-clipboard"></i> Copy Form Link
                                </button> 
                            </div>
                        </div>
                    </h5>
                </div>

                <form action="<?php echo e(route('formbuilder::forms.update', $form)); ?>" method="POST" id="createFormForm" data-form-method="PUT">
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="name" class="col-form-label">Form Name</label>

                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name') ?? $form->name); ?>" required autofocus placeholder="Enter Form Name">

                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="visibility" class="col-form-label">Form Visibility</label>

                                    <select name="visibility" id="visibility" class="form-control" required="required">
                                        <option value="">Select Form Visibility</option>
                                        <?php $__currentLoopData = jazmy\FormBuilder\Models\Form::$visibility_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($option['id']); ?>" <?php if($form->visibility == $option['id']): ?> selected <?php endif; ?>>
                                                <?php echo e($option['name']); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php if($errors->has('visibility')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('visibility')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4" <?php if($form->isPublic()): ?> style="display: none;" id="allows_edit_DIV" <?php endif; ?>>
                                <div class="form-group">
                                    <label for="allows_edit" class="col-form-label">
                                        Allow Submission Edit
                                    </label>

                                    <select name="allows_edit" id="allows_edit" class="form-control" required="required">
                                        <option value="0" <?php if($form->allows_edit == 0): ?> selected <?php endif; ?>>
                                            NO (submissions are final)
                                        </option>
                                        <option value="1" <?php if($form->allows_edit == 1): ?> selected <?php endif; ?>>
                                            YES (allow users to edit their submissions)
                                        </option>
                                    </select>

                                    <?php if($errors->has('allows_edit')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('allows_edit')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="alert alert-info" role="alert">
                                    <i class="fa fa-info-circle"></i> 
                                    Click on or Drag and drop components onto the main panel to build your form content.
                                </div>

                                <div id="fb-editor" class="fb-editor"></div>
                            </div>
                        </div>
                    </div>
                </form>

                <div class="card-footer" id="fb-editor-footer" style="display: none;">
                    <button type="button" class="btn btn-primary fb-clear-btn">
                        <i class="fa fa-remove"></i> Clear Form 
                    </button> 
                    <button type="button" class="btn btn-primary fb-save-btn">
                        <i class="fa fa-save"></i> Submit &amp; Save Form
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush(config('formbuilder.layout_js_stack', 'scripts')); ?>
    <script type="text/javascript">
        window.FormBuilder = window.FormBuilder || {}
        window.FormBuilder.form_roles = <?php echo json_encode($form_roles, 15, 512) ?>;
        
        window._form_builder_content = <?php echo json_encode($form->form_builder_json); ?>

    </script>
    <script src="<?php echo e(asset('vendor/formbuilder/js/create-form.js')); ?><?php echo e(jazmy\FormBuilder\Helper::bustCache()); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/vendor/formbuilder/forms/edit.blade.php ENDPATH**/ ?>