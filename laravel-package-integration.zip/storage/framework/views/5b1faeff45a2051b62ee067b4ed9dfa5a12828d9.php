<?php $__env->startPrepend(config('formbuilder.layout_js_stack', 'scripts')); ?>
	<script type="text/javascript">
		window.FormBuilder = {
			csrfToken: '<?php echo e(csrf_token()); ?>',
		}
	</script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/jquery-ui.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/sweetalert.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/jquery-formbuilder/form-builder.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/jquery-formbuilder/form-render.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/parsleyjs/parsley.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/clipboard/clipboard.min.js')); ?>?b=ck24" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/moment.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/footable/js/footable.min.js')); ?>" defer></script>
	<script src="<?php echo e(asset('vendor/formbuilder/js/script.js')); ?><?php echo e(jazmy\FormBuilder\Helper::bustCache()); ?>" defer></script>
<?php $__env->stopPrepend(); ?>

<?php $__env->startPrepend(config('formbuilder.layout_css_stack', 'scripts')); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/formbuilder/js/footable/css/footable.standalone.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/formbuilder/css/styles.css')); ?><?php echo e(jazmy\FormBuilder\Helper::bustCache()); ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopPrepend(); ?>

<?php echo $__env->make(config('formbuilder.layout_file', 'layouts.app'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/vendor/formbuilder/layout.blade.php ENDPATH**/ ?>