<?php $__env->startSection('content'); ?>
<div class="">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title">
                        Form Preview for '<?php echo e($form->name); ?>' 

                        <div class="btn-toolbar float-md-right" role="toolbar">
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('formbuilder::forms.index')); ?>" class="btn btn-primary float-md-right btn-sm">
                                    <i class="fa fa-arrow-left"></i> 
                                </a>
                                <a href="<?php echo e(route('formbuilder::forms.submissions.index', $form)); ?>" class="btn btn-primary float-md-right btn-sm">
                                    <i class="fa fa-th-list"></i> Submissions
                                </a> 
                                <a href="<?php echo e(route('formbuilder::forms.edit', $form)); ?>" class="btn btn-primary float-md-right btn-sm">
                                    <i class="fa fa-edit"></i> Edit
                                </a> 
                                <a href="<?php echo e(route('formbuilder::forms.create')); ?>" class="btn btn-primary float-md-right btn-sm">
                                    <i class="fa fa-plus-circle"></i> New Form
                                </a>
                            </div>
                        </div>
                    </h5>
                </div>

                <div class="card-body">
                    <div id="fb-render"></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card rounded-0">
                <div class="card-header">
                    <h5 class="card-title">
                        Details 
                        
                        <button class="btn btn-primary btn-sm clipboard float-right" data-clipboard-text="<?php echo e(route('formbuilder::form.render', $form->identifier)); ?>" data-message="Copied" data-original="Copy Form URL" title="Copy form URL to clipboard">
                            <i class="fa fa-clipboard"></i> Copy Form URL
                        </button> 
                    </h5>
                </div>

                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        <strong>Public URL: </strong> 
                        <a href="<?php echo e(route('formbuilder::form.render', $form->identifier)); ?>" class="float-right" target="_blank">
                            <?php echo e($form->identifier); ?>

                        </a>
                    </li>
                    <li class="list-group-item">
                        <strong>Visibility: </strong> <span class="float-right"><?php echo e($form->visibility); ?></span>
                    </li>
                    <li class="list-group-item">
                        <strong>Allows Edit: </strong> 
                        <span class="float-right"><?php echo e($form->allowsEdit() ? 'YES' : 'NO'); ?></span>
                    </li>
                    <li class="list-group-item">
                        <strong>Owner: </strong> <span class="float-right"><?php echo e($form->user->name); ?></span>
                    </li>
                     <li class="list-group-item">
                        <strong>Current Submissions: </strong> 
                        <span class="float-right"><?php echo e($form->submissions_count); ?></span>
                    </li>
                    <li class="list-group-item">
                        <strong>Last Updated On: </strong> 
                        <span class="float-right">
                            <?php echo e($form->updated_at->toDayDateTimeString()); ?>

                        </span>
                    </li>
                    <li class="list-group-item">
                        <strong>Created On: </strong> 
                        <span class="float-right">
                            <?php echo e($form->created_at->toDayDateTimeString()); ?>

                        </span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush(config('formbuilder.layout_js_stack', 'scripts')); ?>
    <script type="text/javascript">
        window._form_builder_content = <?php echo json_encode($form->form_builder_json); ?>

    </script>
    <script src="<?php echo e(asset('vendor/formbuilder/js/preview-form.js')); ?><?php echo e(jazmy\FormBuilder\Helper::bustCache()); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('formbuilder::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/vendor/formbuilder/forms/show.blade.php ENDPATH**/ ?>